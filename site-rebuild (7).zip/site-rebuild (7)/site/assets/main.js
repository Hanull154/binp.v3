// هوشمند تجارت ندا پاسارگاد — اسکریپت مشترک تمام صفحات (یک نسخه، بدون تکرار)
document.addEventListener('DOMContentLoaded', () => {

  /* دکمه بازگشت به بالا */
  const toTop = document.querySelector('.to-top');
  if (toTop) {
    window.addEventListener('scroll', () => {
      toTop.classList.toggle('is-visible', window.scrollY > 480);
    });
    toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  /* منوی مگا در موبایل */
  document.querySelectorAll('.has-mega > a').forEach(link => {
    link.addEventListener('click', (e) => {
      if (window.innerWidth <= 720) {
        e.preventDefault();
        link.parentElement.classList.toggle('is-open');
      }
    });
  });

  /* تب‌های فناوری‌ها */
  const techTabs = document.querySelectorAll('.tech-tab');
  techTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      techTabs.forEach(t => t.classList.remove('is-active'));
      document.querySelectorAll('.tech-panel').forEach(p => p.classList.remove('is-active'));
      tab.classList.add('is-active');
      document.getElementById(tab.dataset.target)?.classList.add('is-active');
    });
  });

  /* ریل دوره‌ها */
  const courseTabs = document.querySelectorAll('.course-rail button');
  courseTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      courseTabs.forEach(t => t.classList.remove('is-active'));
      document.querySelectorAll('.course-set').forEach(p => p.classList.remove('is-active'));
      tab.classList.add('is-active');
      document.getElementById(tab.dataset.target)?.classList.add('is-active');
    });
  });

  /* فرم تماس (نمایشی) */
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const original = btn.textContent;
      btn.textContent = 'در حال ارسال...';
      setTimeout(() => {
        btn.textContent = 'پیام شما ثبت شد ✓';
        form.reset();
        setTimeout(() => (btn.textContent = original), 2600);
      }, 700);
    });
  }

  /* ------------------------------------------------------------------
     اسکرول‌ریویل: کارت‌ها و بخش‌ها هنگام ورود به دید، فید و بالا می‌آیند
     ------------------------------------------------------------------ */
  const revealTargets = document.querySelectorAll(
    '.card, .client-col, .tech-item, .course-row, .head, .contact-info, #contact-form, .testi-item, .faq-item'
  );
  revealTargets.forEach(el => el.classList.add('reveal'));

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  revealTargets.forEach(el => io.observe(el));

  /* ------------------------------------------------------------------
     شمارنده‌ی آماری هیرو: از صفر تا عدد هدف هنگام ورود به دید
     ------------------------------------------------------------------ */
  const faDigits = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  const toFa = n => String(n).split('').map(d => (d >= '0' && d <= '9') ? faDigits[d] : d).join('');

  document.querySelectorAll('.stat b[data-count]').forEach(el => {
    const target = parseInt(el.dataset.count, 10);
    const suffix = el.dataset.suffix || '';
    const counterIO = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        counterIO.unobserve(entry.target);
        let start = null;
        const dur = 1400;
        function step(ts) {
          if (!start) start = ts;
          const p = Math.min((ts - start) / dur, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          el.textContent = toFa(Math.round(eased * target)) + suffix;
          if (p < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      });
    }, { threshold: 0.4 });
    counterIO.observe(el);
  });

  /* ------------------------------------------------------------------
     نور تعقیب‌کننده‌ی موس در هیرو
     ------------------------------------------------------------------ */
  const hero = document.querySelector('.hero');
  if (hero) {
    hero.addEventListener('pointermove', (e) => {
      const r = hero.getBoundingClientRect();
      hero.style.setProperty('--mx', `${((e.clientX - r.left) / r.width) * 100}%`);
      hero.style.setProperty('--my', `${((e.clientY - r.top) / r.height) * 100}%`);
    });
  }
});
